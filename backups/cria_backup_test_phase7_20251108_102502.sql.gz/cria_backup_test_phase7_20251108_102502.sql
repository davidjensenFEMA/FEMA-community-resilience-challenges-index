--
-- PostgreSQL database dump
--

\restrict T5CtKtag9ZDshAlW4BBg5M3Ui4P4PcQCD6WwXXYlMfONYuxH2jV39L5ZDNTDexe

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aggregate_indicators; Type: TABLE; Schema: public; Owner: cria_user
--

CREATE TABLE public.aggregate_indicators (
    id integer NOT NULL,
    geography_id integer NOT NULL,
    aggregate_score double precision,
    z_score double precision,
    bin_class integer,
    percentile double precision,
    economic_score double precision,
    social_score double precision,
    infrastructure_score double precision,
    num_indicators_used integer,
    num_indicators_missing integer,
    imputation_rate double precision,
    year integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    CONSTRAINT check_bin_class CHECK (((bin_class >= 1) AND (bin_class <= 7)))
);


ALTER TABLE public.aggregate_indicators OWNER TO cria_user;

--
-- Name: aggregate_indicators_id_seq; Type: SEQUENCE; Schema: public; Owner: cria_user
--

CREATE SEQUENCE public.aggregate_indicators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aggregate_indicators_id_seq OWNER TO cria_user;

--
-- Name: aggregate_indicators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cria_user
--

ALTER SEQUENCE public.aggregate_indicators_id_seq OWNED BY public.aggregate_indicators.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: cria_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO cria_user;

--
-- Name: data_years; Type: TABLE; Schema: public; Owner: cria_user
--

CREATE TABLE public.data_years (
    id integer NOT NULL,
    source character varying(20) NOT NULL,
    year integer NOT NULL,
    description text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.data_years OWNER TO cria_user;

--
-- Name: data_years_id_seq; Type: SEQUENCE; Schema: public; Owner: cria_user
--

CREATE SEQUENCE public.data_years_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.data_years_id_seq OWNER TO cria_user;

--
-- Name: data_years_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cria_user
--

ALTER SEQUENCE public.data_years_id_seq OWNED BY public.data_years.id;


--
-- Name: geographies; Type: TABLE; Schema: public; Owner: cria_user
--

CREATE TABLE public.geographies (
    id integer NOT NULL,
    geo_id character varying(30) NOT NULL,
    name character varying(255) NOT NULL,
    geography_level character varying(20) NOT NULL,
    state_code character varying(2),
    state_name character varying(100),
    state_abbr character varying(2),
    county_code character varying(3),
    county_name character varying(100),
    tract_code character varying(6),
    tract_name character varying(100),
    region character varying(50),
    population integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT check_geography_level CHECK (((geography_level)::text = ANY ((ARRAY['state'::character varying, 'county'::character varying, 'tract'::character varying, 'tribal'::character varying])::text[])))
);


ALTER TABLE public.geographies OWNER TO cria_user;

--
-- Name: geographies_id_seq; Type: SEQUENCE; Schema: public; Owner: cria_user
--

CREATE SEQUENCE public.geographies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.geographies_id_seq OWNER TO cria_user;

--
-- Name: geographies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cria_user
--

ALTER SEQUENCE public.geographies_id_seq OWNED BY public.geographies.id;


--
-- Name: indicator_metadata; Type: TABLE; Schema: public; Owner: cria_user
--

CREATE TABLE public.indicator_metadata (
    id integer NOT NULL,
    indicator_id integer NOT NULL,
    label text,
    notes text,
    warnings text,
    source_citation text,
    last_verified timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.indicator_metadata OWNER TO cria_user;

--
-- Name: indicator_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: cria_user
--

CREATE SEQUENCE public.indicator_metadata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.indicator_metadata_id_seq OWNER TO cria_user;

--
-- Name: indicator_metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cria_user
--

ALTER SEQUENCE public.indicator_metadata_id_seq OWNED BY public.indicator_metadata.id;


--
-- Name: indicators; Type: TABLE; Schema: public; Owner: cria_user
--

CREATE TABLE public.indicators (
    id integer NOT NULL,
    geography_id integer NOT NULL,
    indicator_id integer NOT NULL,
    value double precision,
    is_clean boolean NOT NULL,
    is_imputed boolean NOT NULL,
    year integer NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.indicators OWNER TO cria_user;

--
-- Name: indicators_id_seq; Type: SEQUENCE; Schema: public; Owner: cria_user
--

CREATE SEQUENCE public.indicators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.indicators_id_seq OWNER TO cria_user;

--
-- Name: indicators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cria_user
--

ALTER SEQUENCE public.indicators_id_seq OWNED BY public.indicators.id;


--
-- Name: reference_indicators; Type: TABLE; Schema: public; Owner: cria_user
--

CREATE TABLE public.reference_indicators (
    id integer NOT NULL,
    indicator_name character varying(100) NOT NULL,
    source character varying(20) NOT NULL,
    function character varying(50) NOT NULL,
    numerator text,
    denominator text,
    rate double precision,
    category character varying(50),
    description text,
    order_2023 integer,
    year_source character varying(20),
    is_active boolean NOT NULL,
    reverse_polarity boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    CONSTRAINT check_function CHECK (((function)::text = ANY ((ARRAY['divide'::character varying, 'max'::character varying, 'mean'::character varying, 'divide_scalar'::character varying, 'reverse_divide'::character varying])::text[]))),
    CONSTRAINT check_source CHECK (((source)::text = ANY ((ARRAY['ACS'::character varying, 'CBP'::character varying, 'EAVS'::character varying, 'ARDA'::character varying, 'POP'::character varying])::text[])))
);


ALTER TABLE public.reference_indicators OWNER TO cria_user;

--
-- Name: reference_indicators_id_seq; Type: SEQUENCE; Schema: public; Owner: cria_user
--

CREATE SEQUENCE public.reference_indicators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reference_indicators_id_seq OWNER TO cria_user;

--
-- Name: reference_indicators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cria_user
--

ALTER SEQUENCE public.reference_indicators_id_seq OWNED BY public.reference_indicators.id;


--
-- Name: source_data; Type: TABLE; Schema: public; Owner: cria_user
--

CREATE TABLE public.source_data (
    id integer NOT NULL,
    geography_id integer NOT NULL,
    indicator_id integer NOT NULL,
    column_name character varying(50) NOT NULL,
    value double precision,
    label text,
    year integer NOT NULL,
    is_imputed boolean NOT NULL,
    source_url text,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.source_data OWNER TO cria_user;

--
-- Name: source_data_id_seq; Type: SEQUENCE; Schema: public; Owner: cria_user
--

CREATE SEQUENCE public.source_data_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.source_data_id_seq OWNER TO cria_user;

--
-- Name: source_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cria_user
--

ALTER SEQUENCE public.source_data_id_seq OWNED BY public.source_data.id;


--
-- Name: aggregate_indicators id; Type: DEFAULT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.aggregate_indicators ALTER COLUMN id SET DEFAULT nextval('public.aggregate_indicators_id_seq'::regclass);


--
-- Name: data_years id; Type: DEFAULT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.data_years ALTER COLUMN id SET DEFAULT nextval('public.data_years_id_seq'::regclass);


--
-- Name: geographies id; Type: DEFAULT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.geographies ALTER COLUMN id SET DEFAULT nextval('public.geographies_id_seq'::regclass);


--
-- Name: indicator_metadata id; Type: DEFAULT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.indicator_metadata ALTER COLUMN id SET DEFAULT nextval('public.indicator_metadata_id_seq'::regclass);


--
-- Name: indicators id; Type: DEFAULT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.indicators ALTER COLUMN id SET DEFAULT nextval('public.indicators_id_seq'::regclass);


--
-- Name: reference_indicators id; Type: DEFAULT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.reference_indicators ALTER COLUMN id SET DEFAULT nextval('public.reference_indicators_id_seq'::regclass);


--
-- Name: source_data id; Type: DEFAULT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.source_data ALTER COLUMN id SET DEFAULT nextval('public.source_data_id_seq'::regclass);


--
-- Data for Name: aggregate_indicators; Type: TABLE DATA; Schema: public; Owner: cria_user
--

COPY public.aggregate_indicators (id, geography_id, aggregate_score, z_score, bin_class, percentile, economic_score, social_score, infrastructure_score, num_indicators_used, num_indicators_missing, imputation_rate, year, created_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: cria_user
--

COPY public.alembic_version (version_num) FROM stdin;
426332235da3
\.


--
-- Data for Name: data_years; Type: TABLE DATA; Schema: public; Owner: cria_user
--

COPY public.data_years (id, source, year, description, created_at, updated_at) FROM stdin;
1	acs	2023	acs data year 2023	2025-11-08 16:14:06.662265	2025-11-08 16:14:06.662267
2	cbp	2021	cbp data year 2021	2025-11-08 16:14:06.662268	2025-11-08 16:14:06.662268
3	naics	2017	naics data year 2017	2025-11-08 16:14:06.662269	2025-11-08 16:14:06.662269
4	pop	2022	pop data year 2022	2025-11-08 16:14:06.66227	2025-11-08 16:14:06.66227
5	acs_labels	2023	acs_labels data year 2023	2025-11-08 16:14:06.662271	2025-11-08 16:14:06.662271
6	asarb	2020	asarb data year 2020	2025-11-08 16:14:06.662271	2025-11-08 16:14:06.662272
\.


--
-- Data for Name: geographies; Type: TABLE DATA; Schema: public; Owner: cria_user
--

COPY public.geographies (id, geo_id, name, geography_level, state_code, state_name, state_abbr, county_code, county_name, tract_code, tract_name, region, population, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: indicator_metadata; Type: TABLE DATA; Schema: public; Owner: cria_user
--

COPY public.indicator_metadata (id, indicator_id, label, notes, warnings, source_citation, last_verified, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: indicators; Type: TABLE DATA; Schema: public; Owner: cria_user
--

COPY public.indicators (id, geography_id, indicator_id, value, is_clean, is_imputed, year, created_at) FROM stdin;
\.


--
-- Data for Name: reference_indicators; Type: TABLE DATA; Schema: public; Owner: cria_user
--

COPY public.reference_indicators (id, indicator_name, source, function, numerator, denominator, rate, category, description, order_2023, year_source, is_active, reverse_polarity, created_at, updated_at) FROM stdin;
1	Mobile Homes	ACS	divide	DP04_0014E	DP04_0001E	\N	\N	\N	1	\N	t	f	2025-11-08 16:14:06.621858	2025-11-08 16:14:06.621861
2	Owner Occupied	ACS	divide	DP04_0046E	DP04_0001E	\N	\N	\N	2	\N	t	f	2025-11-08 16:14:06.621862	2025-11-08 16:14:06.621862
3	Education	ACS	divide	S1501_C01_007E, S1501_C01_008E	S1501_C01_006E	\N	\N	\N	3	\N	t	f	2025-11-08 16:14:06.621866	2025-11-08 16:14:06.621867
4	No Vehicle	ACS	divide	B08201_002E	B08201_001E	\N	\N	\N	4	\N	t	f	2025-11-08 16:14:06.621868	2025-11-08 16:14:06.621868
5	Age	ACS	divide	S0101_C01_030E	S0101_C01_001E	\N	\N	\N	5	\N	t	f	2025-11-08 16:14:06.621869	2025-11-08 16:14:06.62187
6	Disability	ACS	divide	S1810_C02_001E	S1810_C01_001E	\N	\N	\N	6	\N	t	f	2025-11-08 16:14:06.62187	2025-11-08 16:14:06.621871
7	Limited English	ACS	divide	S1602_C03_001E	S1602_C01_001E	\N	\N	\N	7	\N	t	f	2025-11-08 16:14:06.621871	2025-11-08 16:14:06.621872
8	Single Parent	ACS	divide	B09005_004E, B09005_005E	B09005_001E	\N	\N	\N	8	\N	t	f	2025-11-08 16:14:06.621872	2025-11-08 16:14:06.621873
9	Low Access to Communications	ACS	reverse_divide	S2801_C01_005E	S2801_C01_001E	\N	\N	\N	9	\N	t	f	2025-11-08 16:14:06.621873	2025-11-08 16:14:06.621874
10	Inactive Voter	EAVS	divide	A1c	A1a	\N	\N	\N	10	\N	t	f	2025-11-08 16:14:06.621874	2025-11-08 16:14:06.621875
11	Civil Org	CBP	divide_scalar	813410	S0101_C01_001E	10	\N	\N	11	\N	t	f	2025-11-08 16:14:06.621875	2025-11-08 16:14:06.621876
12	Population Change	POP	mean	NETMIG	S0101_C01_001E	\N	\N	\N	12	\N	t	f	2025-11-08 16:14:06.621876	2025-11-08 16:14:06.621877
13	Religion	ARDA	reverse_divide	TOTADH	POP	\N	\N	\N	13	\N	t	f	2025-11-08 16:14:06.621877	2025-11-08 16:14:06.621878
14	Unemployment	ACS	divide	DP03_0005E	DP03_0003E	\N	\N	\N	14	\N	t	f	2025-11-08 16:14:06.621878	2025-11-08 16:14:06.621879
15	Unemployed Women	ACS	reverse_divide	DP03_0013E	DP03_0012E	\N	\N	\N	15	\N	t	f	2025-11-08 16:14:06.621879	2025-11-08 16:14:06.62188
16	Median Income	ACS	divide	S1903_C03_001E	1	\N	\N	\N	16	\N	t	f	2025-11-08 16:14:06.62188	2025-11-08 16:14:06.621881
17	GINI	ACS	divide	B19083_001E	1	\N	\N	\N	17	\N	t	f	2025-11-08 16:14:06.621881	2025-11-08 16:14:06.621882
18	Lack of Economic Diversity	ACS	max	DP03_0033E, DP03_0034E, DP03_0035E, DP03_0036E, DP03_0037E, DP03_0038E, DP03_0039E, DP03_0040E, DP03_0041E, DP03_0042E, DP03_0043E, DP03_0044E, DP03_0045E	DP03_0032E	\N	\N	\N	18	\N	t	f	2025-11-08 16:14:06.621882	2025-11-08 16:14:06.621883
19	Poverty	ACS	divide	S1701_C02_001E	S1701_C01_001E	\N	\N	\N	19	\N	t	f	2025-11-08 16:14:06.621883	2025-11-08 16:14:06.621884
20	Hospitals	CBP	divide_scalar	622110	S0101_C01_001E	10	\N	\N	20	\N	t	f	2025-11-08 16:14:06.621884	2025-11-08 16:14:06.621885
21	Medical	ACS	divide_scalar	S2401_C01_016E	S0101_C01_001E	1	\N	\N	21	\N	t	f	2025-11-08 16:14:06.621885	2025-11-08 16:14:06.621886
22	Uninsured Population	ACS	divide	S2701_C04_001E	S2701_C01_001E	\N	\N	\N	22	\N	t	f	2025-11-08 16:14:06.621886	2025-11-08 16:14:06.621887
\.


--
-- Data for Name: source_data; Type: TABLE DATA; Schema: public; Owner: cria_user
--

COPY public.source_data (id, geography_id, indicator_id, column_name, value, label, year, is_imputed, source_url, created_at) FROM stdin;
\.


--
-- Name: aggregate_indicators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cria_user
--

SELECT pg_catalog.setval('public.aggregate_indicators_id_seq', 1, false);


--
-- Name: data_years_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cria_user
--

SELECT pg_catalog.setval('public.data_years_id_seq', 6, true);


--
-- Name: geographies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cria_user
--

SELECT pg_catalog.setval('public.geographies_id_seq', 1, false);


--
-- Name: indicator_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cria_user
--

SELECT pg_catalog.setval('public.indicator_metadata_id_seq', 1, false);


--
-- Name: indicators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cria_user
--

SELECT pg_catalog.setval('public.indicators_id_seq', 1, false);


--
-- Name: reference_indicators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cria_user
--

SELECT pg_catalog.setval('public.reference_indicators_id_seq', 22, true);


--
-- Name: source_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cria_user
--

SELECT pg_catalog.setval('public.source_data_id_seq', 1, false);


--
-- Name: aggregate_indicators aggregate_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.aggregate_indicators
    ADD CONSTRAINT aggregate_indicators_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: data_years data_years_pkey; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.data_years
    ADD CONSTRAINT data_years_pkey PRIMARY KEY (id);


--
-- Name: geographies geographies_pkey; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.geographies
    ADD CONSTRAINT geographies_pkey PRIMARY KEY (id);


--
-- Name: indicator_metadata indicator_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.indicator_metadata
    ADD CONSTRAINT indicator_metadata_pkey PRIMARY KEY (id);


--
-- Name: indicators indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.indicators
    ADD CONSTRAINT indicators_pkey PRIMARY KEY (id);


--
-- Name: reference_indicators reference_indicators_indicator_name_key; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.reference_indicators
    ADD CONSTRAINT reference_indicators_indicator_name_key UNIQUE (indicator_name);


--
-- Name: reference_indicators reference_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.reference_indicators
    ADD CONSTRAINT reference_indicators_pkey PRIMARY KEY (id);


--
-- Name: source_data source_data_pkey; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.source_data
    ADD CONSTRAINT source_data_pkey PRIMARY KEY (id);


--
-- Name: aggregate_indicators uq_aggregate; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.aggregate_indicators
    ADD CONSTRAINT uq_aggregate UNIQUE (geography_id, year);


--
-- Name: data_years uq_data_year; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.data_years
    ADD CONSTRAINT uq_data_year UNIQUE (source, year);


--
-- Name: indicators uq_indicator; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.indicators
    ADD CONSTRAINT uq_indicator UNIQUE (geography_id, indicator_id, year);


--
-- Name: source_data uq_source_data; Type: CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.source_data
    ADD CONSTRAINT uq_source_data UNIQUE (geography_id, indicator_id, column_name, year);


--
-- Name: idx_geographies_state_county; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX idx_geographies_state_county ON public.geographies USING btree (state_code, county_code);


--
-- Name: idx_indicators_composite; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX idx_indicators_composite ON public.indicators USING btree (geography_id, indicator_id, year);


--
-- Name: idx_source_data_composite; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX idx_source_data_composite ON public.source_data USING btree (geography_id, indicator_id, year);


--
-- Name: ix_aggregate_indicators_bin_class; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_aggregate_indicators_bin_class ON public.aggregate_indicators USING btree (bin_class);


--
-- Name: ix_aggregate_indicators_geography_id; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_aggregate_indicators_geography_id ON public.aggregate_indicators USING btree (geography_id);


--
-- Name: ix_aggregate_indicators_percentile; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_aggregate_indicators_percentile ON public.aggregate_indicators USING btree (percentile);


--
-- Name: ix_aggregate_indicators_year; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_aggregate_indicators_year ON public.aggregate_indicators USING btree (year);


--
-- Name: ix_data_years_source; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_data_years_source ON public.data_years USING btree (source);


--
-- Name: ix_geographies_geo_id; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE UNIQUE INDEX ix_geographies_geo_id ON public.geographies USING btree (geo_id);


--
-- Name: ix_geographies_geography_level; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_geographies_geography_level ON public.geographies USING btree (geography_level);


--
-- Name: ix_geographies_state_code; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_geographies_state_code ON public.geographies USING btree (state_code);


--
-- Name: ix_indicator_metadata_indicator_id; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_indicator_metadata_indicator_id ON public.indicator_metadata USING btree (indicator_id);


--
-- Name: ix_indicators_geography_id; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_indicators_geography_id ON public.indicators USING btree (geography_id);


--
-- Name: ix_indicators_indicator_id; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_indicators_indicator_id ON public.indicators USING btree (indicator_id);


--
-- Name: ix_indicators_year; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_indicators_year ON public.indicators USING btree (year);


--
-- Name: ix_reference_indicators_is_active; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_reference_indicators_is_active ON public.reference_indicators USING btree (is_active);


--
-- Name: ix_reference_indicators_source; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_reference_indicators_source ON public.reference_indicators USING btree (source);


--
-- Name: ix_source_data_geography_id; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_source_data_geography_id ON public.source_data USING btree (geography_id);


--
-- Name: ix_source_data_indicator_id; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_source_data_indicator_id ON public.source_data USING btree (indicator_id);


--
-- Name: ix_source_data_year; Type: INDEX; Schema: public; Owner: cria_user
--

CREATE INDEX ix_source_data_year ON public.source_data USING btree (year);


--
-- Name: aggregate_indicators aggregate_indicators_geography_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.aggregate_indicators
    ADD CONSTRAINT aggregate_indicators_geography_id_fkey FOREIGN KEY (geography_id) REFERENCES public.geographies(id) ON DELETE CASCADE;


--
-- Name: indicator_metadata indicator_metadata_indicator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.indicator_metadata
    ADD CONSTRAINT indicator_metadata_indicator_id_fkey FOREIGN KEY (indicator_id) REFERENCES public.reference_indicators(id) ON DELETE CASCADE;


--
-- Name: indicators indicators_geography_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.indicators
    ADD CONSTRAINT indicators_geography_id_fkey FOREIGN KEY (geography_id) REFERENCES public.geographies(id) ON DELETE CASCADE;


--
-- Name: indicators indicators_indicator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.indicators
    ADD CONSTRAINT indicators_indicator_id_fkey FOREIGN KEY (indicator_id) REFERENCES public.reference_indicators(id) ON DELETE CASCADE;


--
-- Name: source_data source_data_geography_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.source_data
    ADD CONSTRAINT source_data_geography_id_fkey FOREIGN KEY (geography_id) REFERENCES public.geographies(id) ON DELETE CASCADE;


--
-- Name: source_data source_data_indicator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cria_user
--

ALTER TABLE ONLY public.source_data
    ADD CONSTRAINT source_data_indicator_id_fkey FOREIGN KEY (indicator_id) REFERENCES public.reference_indicators(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict T5CtKtag9ZDshAlW4BBg5M3Ui4P4PcQCD6WwXXYlMfONYuxH2jV39L5ZDNTDexe

